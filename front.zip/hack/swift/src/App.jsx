import { BrowserRouter as Router } from 'react-router-dom';
import FormData from './pages/FormData';



function App() {
  return (
    <Router>
      <div>
        <h1>My Form</h1>
        <FormData />
      </div>
    </Router>
  );
}

export default App;