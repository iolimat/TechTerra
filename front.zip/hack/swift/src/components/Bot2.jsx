import { useState, useEffect } from 'react';
import '../css/ChatbotDesign.css';
import botImage from '../assets/bot.png';
import inputImage from '../assets/user.png';

const Bot2 = ({ showContent }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [chatHistory, setChatHistory] = useState([{ message: "Hello, I'm swift", sender: 'bot' }]);
  const [toggleBtnVisible, setToggleBtnVisible] = useState(true);

  useEffect(() => {
    setIsOpen(showContent); 
    setToggleBtnVisible(!showContent); 
  }, [showContent]);

  const toggleChatbot = () => {
    setIsOpen(!isOpen);
    setToggleBtnVisible(false);
  };

  const closeChatbot = () => {
    setIsOpen(false);
    setToggleBtnVisible(true);
  };

  const handleInputChange = (e) => {
    setMessage(e.target.value);
  };

  const handleSendMessage = () => {
    if (message.trim() !== '') {
      setChatHistory([...chatHistory, { message, sender: 'user' }]);
      setMessage('');
      // backend
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  const handleToggle = () => {
    setIsOpen(!isOpen); 
    setToggleBtnVisible(false);
  };

  return (
    <div className="chatbot">
      {toggleBtnVisible && (
        <button className="chatbot-toggle-btn" onClick={handleToggle}></button>
      )}
      {isOpen && (
        <div className="chatbot-container">
          <div className="chatbot-header">
            <h3></h3>
            <button className="close-btn" onClick={closeChatbot}>
              X
            </button>
          </div>
          <div className="chat-history">
            {chatHistory.map((item, index) => (
              <div key={index} className={`message ${item.sender}`}>
                {item.sender === 'bot' && <img src={botImage} alt="Bot" className="avatar" />}
                {item.sender === 'user' && <img src={inputImage} alt="User" className="avatar user" />}
                <div className="message-text">{item.message}</div>
              </div>
            ))}
          </div>
          <div className="input-container">
            <input
              type="text"
              placeholder="Type a message..."
              value={message}
              onChange={handleInputChange}
              onKeyDown={handleKeyDown} 
              name="Prompt"
            />
            <button className="send-btn" onClick={handleSendMessage}>
              Send
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default Bot2;
