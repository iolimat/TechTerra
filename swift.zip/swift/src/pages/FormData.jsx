import { useState } from 'react';
import axios from 'axios';

function FormData() {
  const initialState = {
    context: 'string',
    types: [true], // Add other initial values for types
    urls: ["string"] // Add other initial values for URLs
  };

  const [formData, setFormData] = useState(initialState);

  const handleContextChange = (e) => {
    const newContext = e.target.value;
    setFormData((prevFormData) => ({
      ...prevFormData,
      context: newContext,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://127.0.0.1:8000/api/user_request', formData);
      console.log('Form submitted successfully:', response.data);
      // Optionally, reset the form after successful submission
      setFormData(initialState); // Resetting to initial state
    } catch (error) {
      console.error('Error submitting form:', error);
      // Handle error state if needed
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>
        Context:
        <input
          type="text"
          value={formData.context}
          onChange={handleContextChange}
        />
      </label>
      {/* Add inputs for other form fields */}
      {/* Add inputs for types */}
      {/* Add inputs for URLs */}
      <button type="submit">Submit</button>
    </form>
  );
}

export default FormData;
