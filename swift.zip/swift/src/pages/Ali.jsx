// Ali.jsx
import robot from '../assets/robot.jpg'
import logo from '../assets/logo.jpg'
import '../ali.css'
import Bot2 from '../components/Bot2';
import { useState } from 'react';

const Ali = () => {
    const [showBotContent, setShowBotContent] = useState(false);

    const handleExperimentClick = () => {
        setShowBotContent(!showBotContent);
    };

    return (
        <>
            <div className="wrapper">
                    <header>
                        <a href="#"><img src={logo} alt="Unit testing Logo"/></a>
                        <nav>
                            <ul>
                                <li><a href="#" className="active">Home</a></li>
                                <li><a href="#">Information</a></li>
                                <li><a href="#">The team</a></li>
                                <li><a href="#">GITHUB</a></li>
                            </ul>
                        </nav>
                    </header>

                    <main>
                        <div className="first">
                            <div className="left-col">
                                <h1>DataSwift</h1>
                                <p className="subhead">
                                Effortlessly find datasets, simplify your workflow, and ensure reliability. 
                                Say goodbye to manual searches and hello to efficient data discovery.
                                </p>
                                <div className="cta-btns">
                                    <a href="#" className="primary-cta">Documentation</a>
                                    
                                    <a href="#" className="secondary-cta" onClick={handleExperimentClick}>
                                        <span>Experiment now </span>
                                        <svg viewBox="0 0 19 8" fill="none">
                                            <path d="M18.3536 4.35355C18.5488 4.15829 18.5488 3.84171 18.3536 3.64645L15.1716 0.464466C14.9763 0.269204 14.6597 0.269204 14.4645 0.464466C14.2692 0.659728 14.2692 0.976311 14.4645 1.17157L17.2929 4L14.4645 6.82843C14.2692 7.02369 14.2692 7.34027 14.4645 7.53553C14.6597 7.7308 14.9763 7.7308 15.1716 7.53553L18.3536 4.35355ZM0 4.5H18V3.5H0V4.5Z" fill="white"/>
                                        </svg> 
                                    </a>
                                </div>
                            </div>
                            <div className="right-col">
                                <img src={robot} alt="robot" className="right-img"/>
                            </div>
                        </div>

                        <div className="information">
                            <h1>Project Information</h1>
                            <p className="subhead">
                                Our initiative transforms Earth observations into actionable insights, guided by 
                                Galileo's principle: "Measure what is measurable,"
                                 equipping decision-makers with crucial data for sustainable development 
                                 through advanced technologies.
                            </p>
                        </div>
                        
                        <div className="information">
                            <h1>The Team</h1>
                        </div>
                        
                        <div className="white-space">
                        </div>
                        </main>
                        <Bot2 showContent={showBotContent} /> {/* Render Bot2 and pass showContent prop */}
                </div>
        </>
    );
}

export default Ali;
